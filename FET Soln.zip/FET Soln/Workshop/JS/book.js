 var arrid;
displayall=()=>{
    newarray=[];
    str=sessionStorage.getItem("books");
    newarray=JSON.parse(str);
    console.log(newarray);
    console.log(newarray[0]);
    console.log(newarray.length);
    div= document.getElementById("list");
    //div.innerHTML="<table><tr><th>Book Id</th><th>Book Name</th><th>Book Price</th></tr> ";
    for(i=0;i<newarray.length;i++)
    {
      //  console.log(newarray[i].bookname);
      
       div.innerHTML+=newarray[i].bookid;
       div.innerHTML+='&nbsp';
        div.innerHTML+=newarray[i].bookname; 
        div.innerHTML+='&nbsp';
        div.innerHTML+=newarray[i].bookprice; 
        div.innerHTML+='&nbsp';
        
        div.innerHTML+='<br>';

   }
  
}

//window.onload=displayall();
bookarray=[];

class Book{
    bookid;
    bookname;
    bookprice;

    constructor(bookid,bookname,bookprice){
        this.bookid=bookid;
        this.bookname=bookname;
        this.bookprice=bookprice;
    }
    
}

function addbook(){
bookid=document.getElementById("bookid").value;
bookname=document.getElementById("bookname").value;
bookprice=document.getElementById("bookprice").value;
newbook=new Book(bookid,bookname,bookprice);
bookarray.push(newbook);
//console.log(newbook);
console.log(bookarray);
sessionStorage.setItem("books",JSON.stringify(bookarray));
//location.replace("../HTML/Workshop1.html");
}


function removebook(){
    bookarray.pop();
    console.log(bookarray);
}

function editdetails(){
    newarray=[];
    str=sessionStorage.getItem("books");
    newarray=JSON.parse(str);
    
    div= document.getElementById("list");
    
    for(i=0;i<newarray.length;i++)
    {
   console.log(newarray[i].bookname);
    div.innerHTML+='<a href="../HTML/editbookdata.html?id='+newarray[i].bookid+'">'+newarray[i].bookname+'</a><br>';
   }
}

function getid(){
    var obj=new URLSearchParams(window.location.search);
    id=obj.get('id');
   
   
    bookarray=[];
   bookarray=JSON.parse(sessionStorage.getItem("books"));
   arrid=0;
   for(i=0;i<bookarray.length;i++)
   {
       if(bookarray[i].bookid==id)
       {
           arrid=i;
       }
   }
   console.log(bookarray[arrid]);
   document.querySelector('[data-model="bid"]').value=bookarray[arrid].bookid;
    document.querySelector('[data-model="bname"]').value=bookarray[arrid].bookname;
    document.querySelector('[data-model="bprice"]').value=bookarray[arrid].bookprice;
    }

    function editedbook(){
       
        
        bookid=document.getElementById("bookid").value;
        bookname=document.getElementById("bookname").value;
        bookprice=document.getElementById("bookprice").value;

       bookarray[arrid].bookname=bookname;
       bookarray[arrid].bookprice=bookprice;

        sessionStorage.setItem("books",JSON.stringify(bookarray));
        location.replace("../HTML/Workshop1.html");
        }

        function deletion(){
            newarray=[];
            str=sessionStorage.getItem("books");
            newarray=JSON.parse(str);
            
            div= document.getElementById("list");
            
            for(i=0;i<newarray.length;i++)
            {
           console.log(newarray[i].bookname);
            div.innerHTML+=newarray[i].bookname+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="../HTML/deletedmsg.html?id='+newarray[i].bookid+'">Delete</a><br>';
           }
        }
        
    function deletedbook()
    {
        var obj=new URLSearchParams(window.location.search);
        id=obj.get('id');
        console.log(id);
        arr=[];
        arr=JSON.parse(sessionStorage.getItem("books"));
        console.log("Before:: "+arr);
        for(i=0;i<arr.length;i++)
        {
            if(arr[i].bookid==id)
            {
                arr.splice(i,1);
            }
        }
            console.log(arr);
        sessionStorage.setItem("books",JSON.stringify(arr));
        document.getElementById("mydiv").innerHTML="BOOK DELETED!!";
       // location.replace("../HTML/Workshop1.html");
    }