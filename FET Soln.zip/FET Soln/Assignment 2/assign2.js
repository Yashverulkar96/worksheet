function myFunction() {
    document.querySelector("#para").style.backgroundColor = "#cc33ff";
  }